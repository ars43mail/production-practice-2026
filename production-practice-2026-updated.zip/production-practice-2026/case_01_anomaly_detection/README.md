# Кейс 1 — Поиск аномалий

- `task.md`, `dataset_description.md`, `submission_template.md` — условия.
- `students.csv` — исходный журнал.
- `analysis.py` — анализ маршрутов, ролей и длительностей.
- `anomalies.csv` — результаты.
- `report.pdf` — окончательный исправленный отчёт.
- `report_draft.docx` — предыдущая редактируемая версия, не для сдачи.

Запуск из корня: `python case_01_anomaly_detection/analysis.py`.
