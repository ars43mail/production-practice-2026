"""Анализ журнала закупок. Запуск: python analysis.py [students.csv]."""
import sys
from pathlib import Path
from collections import Counter
import pandas as pd

BASE = Path(__file__).resolve().parent
SOURCE = Path(sys.argv[1]) if len(sys.argv)>1 else BASE/'students.csv'
x = pd.read_csv(SOURCE, encoding='utf-8-sig').fillna('')
x['Timestamp'] = pd.to_datetime(x.Timestamp)
x = x.sort_values(['ProcessInstanceId','EventIndex'])
cut = pd.Timestamp('2026-07-01T00:00:00+03:00')
P,M,B,L,E,R,A = ('Проверка заявки','Согласование руководителем','Согласование бюджета','Проверка договора','Исполнение заявки','Доработка заявки','Внеплановая проверка')
roles = dict(zip([P,M,B,L,E,R,A],['specialist','manager','finance','legal','procurement','requester','auditor']))
rows=[]
def add(pid, kind, reason):
    rows.append((pid,kind,reason))

def work_minutes(start,end):
    total=0
    day=start.normalize()
    while day<=end.normalize():
        if day.weekday()<5:
            lo=max(start,day+pd.Timedelta(hours=9)); hi=min(end,day+pd.Timedelta(hours=18))
            total+=max(0,(hi-lo).total_seconds()/60)
        day+=pd.Timedelta(days=1)
    return total

created=x[x.EventType=='task_created']; closed=x[x.EventType=='task_completed']
assert x.EventId.is_unique and created.TaskId.is_unique and closed.TaskId.is_unique
assert set(closed.TaskId)<=set(created.TaskId)
assert x.groupby('ProcessInstanceId').EventIndex.apply(lambda s:list(s)==list(range(1,len(s)+1))).all()
print('События после заявленного среза:', (x.Timestamp>cut).sum())
 # Сохраняем все наблюдаемые события; возраст открытых задач считаем на заявленный срез.

pairs=created.merge(closed,on='TaskId',suffixes=('_s','_e'),how='left',validate='one_to_one')
assert (pairs.loc[pairs.Timestamp_e.notna(),'ProcessInstanceId_s']==pairs.loc[pairs.Timestamp_e.notna(),'ProcessInstanceId_e']).all()
assert (pairs.loc[pairs.Timestamp_e.notna(),'ActivityId_s']==pairs.loc[pairs.Timestamp_e.notna(),'ActivityId_e']).all()
pairs['calendar']=(pairs.Timestamp_e.fillna(cut)-pairs.Timestamp_s).dt.total_seconds()/60
pairs['work']=[work_minutes(s,e if pd.notna(e) else cut) for s,e in zip(pairs.Timestamp_s,pairs.Timestamp_e)]
assert (pairs.calendar>=0).all()
# Робастный верхний порог: 1.5 * (Q3 + 3 IQR) по закрытым заданиям того же типа и этапа.
for (typ,act),g in pairs.groupby(['RequestType_s','ActivityName_s']):
    done=g[g.Timestamp_e.notna()]
    if len(done)<20: continue
    q1,med,q3=done.work.quantile([.25,.5,.75]); upper=q3+3*(q3-q1)
    print(typ,act,len(done),round(med,1),round(1.5*upper,1))
    for r in g.itertuples():
        if r.work>upper and r.work>1.5*upper:
            add(r.ProcessInstanceId_s,'Длительное ожидание',f'{act}, TaskId={r.TaskId}: {r.work:.1f} рабочих мин, {r.calendar:.1f} календарных мин; медиана {med:.1f}, порог {1.5*upper:.1f} рабочих мин ({typ}); '+('открыто, нижняя граница' if pd.isna(r.Timestamp_e) else 'закрыто'))
        if pd.notna(r.Timestamp_e) and r.calendar<1:
            add(r.ProcessInstanceId_s,'Сверхбыстрое закрытие',f'{act}, TaskId={r.TaskId}: {r.calendar*60:.0f} секунд; медиана {med:.1f} рабочих мин ({typ}); проверить автоматизацию или формальное закрытие')
for pid,g in x.groupby('ProcessInstanceId'):
    typ=g.RequestType.iloc[0]; c=g[g.EventType=='task_completed']; route=list(c.ActivityName); core=[a for a in route if a!=A]; end=g[g.EventType=='process_completed']; outcome=end.Result.iloc[0] if len(end) else ''
    expected=[P,M]; returns=0
    for r in c.itertuples():
        if r.Role!=roles.get(r.ActivityName): add(pid,'Несоответствие роли',f'{r.ActivityName}, EventIndex={r.EventIndex}: роль {r.Role}, ожидается {roles.get(r.ActivityName)}')
        if r.ActivityName==M and r.Result=='return': returns+=1; expected += [R,P,M]
    last=c[c.ActivityName==M].Result.tolist()
    if not last or last[-1]!='reject': expected += [B]+([L] if typ=='contract' else [])+[E]
    if outcome=='fulfilled' or outcome=='rejected':
        if core!=expected:
            missing=list((Counter(expected)-Counter(core)).elements()); extra=list((Counter(core)-Counter(expected)).elements())
            kind='Пропуск этапа' if missing else ('Лишнее повторение' if extra else 'Нарушение порядка')
            add(pid,kind,'Фактически: '+' > '.join(core)+'; ожидается: '+' > '.join(expected))
    elif core!=expected[:len(core)]: add(pid,'Нарушение порядка','Наблюдаемый префикс: '+' > '.join(core)+'; ожидаемый: '+' > '.join(expected))
    if returns>=3: add(pid,'Многократный возврат',f'Руководитель вернул заявку {returns} раз; порог ручной проверки — 3 возврата')
    if A in route: add(pid,'Внеплановая проверка',f'Внеплановая проверка: {route.count(A)} раз; индексы закрытия {list(c[c.ActivityName==A].EventIndex)}; требуется бизнес-обоснование')
result=pd.DataFrame(rows,columns=['ProcessInstanceId','AnomalyType','Explanation']).drop_duplicates().sort_values(['ProcessInstanceId','AnomalyType','Explanation'])
assert set(result.ProcessInstanceId)<=set(x.ProcessInstanceId)
result.to_csv(BASE/'anomalies.csv',index=False,encoding='utf-8-sig')
print('Кандидаты:',result.ProcessInstanceId.nunique(),'Строки:',len(result)); print(result.AnomalyType.value_counts().to_string())
