# Кейс 2 — Восстановление процесса

- `task.md`, `dataset_description.md`, `submission_template.md` — условия.
- `students.csv` — исходный журнал (ранее students (2).csv).
- `process_discovery.py` — подсчёт вариантов и переходов.
- `variants.csv`, `student_transitions.csv` — результаты.
- `process.png`, `process.dot` — автоматически построенный граф.
- `process_bw.drawio` — редактируемая чёрно-белая схема.
- `report.pdf` — окончательный исправленный отчёт.
- `report_draft.tex` — предыдущий исходник LaTeX, не соответствует окончательному PDF.
- `process.drawio` — первоначальная редактируемая схема.
- `variants_template.csv`, `student_transitions_template.csv` — исходные шаблоны.

Запуск из корня: `python case_02_process_discovery/process_discovery.py`.
