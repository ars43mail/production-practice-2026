"""Восстановление наблюдаемого процесса. Python 3, pandas; Graphviz для PNG."""
from pathlib import Path
from collections import Counter
import argparse
import subprocess
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input', nargs='?', default=str(Path(__file__).resolve().parent / 'students.csv'))
    args = parser.parse_args()
    out = Path(__file__).resolve().parent
    df = pd.read_csv(args.input, encoding='utf-8-sig')
    df['EventIndex'] = pd.to_numeric(df['EventIndex'])
    df = df.sort_values(['ProcessInstanceId', 'EventIndex'])
    assert df.EventId.is_unique
    routes, edges, examples = Counter(), Counter(), {}
    for case, g in df.groupby('ProcessInstanceId'):
        assert list(g.EventIndex) == list(range(1, len(g)+1))
        assert g.EventType.iloc[0] == 'process_started'
        assert g.EventType.iloc[-1] == 'process_completed'
        route = tuple(g.ActivityName)
        routes[route] += 1
        examples.setdefault(route, case)
        edges.update(zip(route, route[1:]))
    total = sum(routes.values())
    ordered = sorted(routes.items(), key=lambda x: (-x[1], x[0]))
    pd.DataFrame([(f'V{i}', ' > '.join(r), n, n/total) for i,(r,n) in enumerate(ordered,1)], columns=['Variant','Route','NumberOfCases','Share']).to_csv(out/'variants.csv',index=False,encoding='utf-8')
    pd.DataFrame(sorted(edges),columns=['SourceActivity','TargetActivity']).to_csv(out/'student_transitions.csv',index=False,encoding='utf-8')
    print('События:',len(df),'Заявки:',total,'Варианты:',len(routes),'Переходы:',len(edges))
    for r,n in ordered: print(n,examples[r],' > '.join(r))
    print(df.groupby('ActivityName').ProcessInstanceId.nunique())
    for (a,b),n in edges.items(): print(a,'->',b,n)
    amount = df.groupby('ProcessInstanceId').Amount.first()
    success = set(df.loc[df.Result=='fulfilled','ProcessInstanceId'])
    extra = set(df.loc[df.ActivityName=='Дополнительное согласование','ProcessInstanceId'])
    print('Максимум без доп. согласования:',amount.loc[sorted(success-extra)].max())
    print('Минимум с доп. согласованием:',amount.loc[sorted(extra)].min())
    print('Совпадение с гипотезой 150000:',sum((amount.loc[c]>150000)==(c in extra) for c in success), '/',len(success))
    # Граф непосредственно следующих активностей; числа на дугах — частоты событий.
    import json
    q=lambda s: json.dumps(s,ensure_ascii=False)
    lines=['digraph G {','graph [rankdir=TB, bgcolor="white", pad=0.25, nodesep=0.35, ranksep=0.55, labelloc=b, label="Стрелка — наблюдаемый переход; число — частота перехода.\\nОвал — начало или исход; прямоугольник — действие.", fontname="DejaVu Sans", fontsize=11];','node [shape=box, style="rounded,filled", fillcolor="#edf3fa", fontname="DejaVu Sans", fontsize=11, margin="0.15,0.10"];','edge [fontname="DejaVu Sans", fontsize=10, color="#475569"];']
    for name in sorted(df.ActivityName.unique()):
        if name=='Регистрация заявки' or name.startswith('Заявка '): lines.append(f'{q(name)} [shape=oval, fillcolor="#e5eee7"];')
    for (a,b),n in sorted(edges.items()): lines.append(f'{q(a)} -> {q(b)} [label="{n}"];')
    lines.append('}')
    (out/'process.dot').write_text('\n'.join(lines),encoding='utf-8')
    try: subprocess.run(['dot','-Tpng','-Gdpi=180',str(out/'process.dot'),'-o',str(out/'process.png')],check=True)
    except FileNotFoundError: print('Graphviz не установлен; DOT-файл сохранён.')

if __name__=='__main__': main()
